#include "List.h"
#include "ListNode.h"

namespace cs52 {

List::List() {
	head = nullptr;
	listSize = 0;
}

List::~List() {
	makeEmpty();
    delete head;
}

bool List::isEmpty() const {
	return( head == nullptr );
}

void List::makeEmpty() {
	while (head != nullptr) {
		remove( head->getElement() );
	}
}

int List::size() const {
	return( listSize );
}

void List::insert( const int& data ) {
	// place data into a ListNode at the front of the list
	// it will move the head node to behind the node 
	//    we create dynamically
	ListNode* temp = head;
	ListNode* newnode = new ListNode( data );
	head = newnode;
	newnode->setNext( temp );
	listSize++;
}

void List::remove( const int& data ) {
	ListNode* current = head;
	ListNode* previous = nullptr;
	ListNode* nodeToRemove = nullptr;
	while (current != nullptr) {
		// have we found it at the current node???
		if (current->getElement() == data) {
			// found it at head node
			if (previous == nullptr) {
				nodeToRemove = head;
				head = head->getNext();
			}
			// found it inside the list somewhere
			else {
				nodeToRemove = current;
				// skip the current node
				previous->setNext( current->getNext() );
			}
			delete( nodeToRemove );
			listSize--;
			break;
		}
		// keep looking
		else {
			previous = current;
			current = current->getNext();
		}
	}
}

std::ostream& operator << ( std::ostream& outs, const List& l) {
	return( l.printList( outs ) );
}

std::ostream& operator << ( std::ostream& outs, const List* l) {
	return( l->printList( outs ) );
}

std::ostream& List::printList( std::ostream& outs ) const {
	if (isEmpty()) 
		outs << "Empty List" << std::endl;
	else {
		outs << "List has " << size() << " elements: " << std::endl;
		ListNode* current = head;
		while (current != nullptr) {
			outs << current->getElement() << " -> ";
			current = current->getNext();
		}
		outs << " nullptr";
		outs << std::endl;
	}
	return( outs );
}



}