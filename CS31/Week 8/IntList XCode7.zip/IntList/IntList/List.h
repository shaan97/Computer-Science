#ifndef LIST_H
#define LIST_H
#include <iostream>
#include "ListNode.h"

namespace cs52 {

class List {
public:
	List();
	~List();

	bool isEmpty() const;
	int  size() const;
	void makeEmpty();
	void insert( const int& data );
	void remove( const int& data );
	
	// use these two lines if running under linux
	// friend std::ostream& operator <<() ( std::ostream& outs, const List& l );
	// friend std::ostream& operator <<() ( std::ostream& outs, const List* l );
	// use these two lines if running under windows
	friend std::ostream& operator << ( std::ostream& outs, const List& l );
	friend std::ostream& operator << ( std::ostream& outs, const List* l );
private:
	ListNode* head;
	int listSize;

	std::ostream& printList( std::ostream& outs ) const;

};

}
#endif