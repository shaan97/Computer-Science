//
//  Dice.cpp
//  Dice
//
//  Created by Howard Stahl on 2/16/16.
//  Copyright © 2016 Howard Stahl. All rights reserved.
//
#include <iostream>
#include <stdexcept>
#include "Dice.h"
#include "RandomNumber.h"


namespace cs31
{
    
Dice::Dice( )
{
	diesArray[ 0 ] = Die( 1 );
	diesArray[ 1 ] = Die( 1 );
}
    
Dice::Dice( int die1, int die2 )
{
	using namespace std;

    diesArray[ 0 ] = Die( die1 );
    diesArray[ 1 ] = Die( die2 );
}
    
    
void Dice::roll()
{
    diesArray[ 0 ].roll( );
    diesArray[ 1 ].roll( );
}
    
int  Dice::getDie1( ) const
{
	return( diesArray[ 0 ].getDie( ) );
}
    
int  Dice::getDie2( ) const
{
	return( diesArray[ 1 ].getDie( ) );
}
    
int  Dice::getTotal( ) const
{
    return( getDie1( ) + getDie2( ) );
}
    
    
    
}