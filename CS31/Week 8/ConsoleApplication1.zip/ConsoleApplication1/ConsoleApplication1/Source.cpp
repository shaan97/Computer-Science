#include <iostream>
#include <stdexcept>
using namespace std;


int main( )
{
	int a = 12;

	int * ptrA;

	ptrA = &a;

	a = 13;
	*ptrA = 14;

	// delete( ptrA );
	// delete ptrA;
	// you need to delete your pointers 
	// when you are done so they can get
	// recycled...

	logic_error * pLE;
//	cout << pLE   ->   what( ) << endl;

	pLE = new logic_error( "message" );

	cout << pLE   ->   what( ) << endl;

	// work....
	delete( pLE );
//	delete( pLE );
//	delete( pLE );

//	cout << pLE   ->   what( ) << endl;


	int array[ 5 ] = {1, 2, 3, 4, 5 };
	int * pInt;

	// array is a pointer to a[ 0 ]
	// blob  of memory
	// a[ 0 ] = 1
	// a[ 1 ] = 2
	// a[ 2 ] = 3 
	// a[ 3 ] = 4
	// a[ 4 ] = 5
	cout << array[ 0 ] << endl;
	pInt = array;   /// the 0th element in our array
	cout << * pInt << endl;
	cout << array[ 1 ] << endl;
	cout << * (pInt + 1) << endl;
	pInt = pInt + 1;
	// same effect
	pInt++;

	for (int j = 0; j < 5; j++)
	{
		cout << array[ j ] << endl;
	}



	int x;
	cin >> x;   /// make an array of size x
	const int SIZE = 78;
	int Pile[ SIZE ];
//	int Pile1[ x ];   /// bad.... not build...


	int * Pile2 = new int[ x ];
	cout << Pile2[ 0 ] << endl;
	Pile2[ 1 ] = 12;
	// delete a dynamic array...
	// delete( Pile2 );   /// build , run, crash
	delete [] Pile2;

	int Pile3[ 5 ];
	cout << Pile3[ 0 ] << endl;


	return( 0 );
}