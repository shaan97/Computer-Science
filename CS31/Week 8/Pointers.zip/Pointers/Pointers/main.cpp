//
//  main.cpp
//  sample
//
//  Created by Howard Stahl on 2/24/16.
//  Copyright © 2016 Howard Stahl. All rights reserved.
//

#include <iostream>
#include <cctype>
using namespace std;

void switchCase( char * data );
bool greaterThan( char * cstring1, char * cstring2 );
void swapArrows( int * i, int * j );
void swapArrowsCorrected( int * & i, int * & j );

int main(int argc, const char * argv[]) {
    // insert code here...
    cout << "Hello, World!" << endl;
    char line[ 80 ];
    strcpy_s( line, "data DATA" );   // security issues with strcpy
    switchCase( line );
    cout << line << endl;
    char data1[ 80 ] = "val";
    char data2[ 80 ] = "val";
    if (greaterThan( data1, data2 ))
    {
        cout << "data1>data2" << endl;
    }
    if (greaterThan( data2, data1 ))
    {
        cout << "data2>data1" << endl;
    }

    int a = 12;
    int b = 13;
    
    int *ptrA = &a;
    int *ptrB = &b;
    
    swapArrows(ptrA, ptrB);
    cout  << "now ptrA points at " << *ptrA << endl;
    cout  << "now ptrB points at " << *ptrB << endl;

    swapArrowsCorrected(ptrA, ptrB);
    cout  << "now ptrA points at " << *ptrA << endl;
    cout  << "now ptrB points at " << *ptrB << endl;
    
    return 0;
}

void switchCase( char * data )
{
    char * ptr = data;
    while (*ptr != '\0')    /// NULL '\0'
    {
        // change the case...
        char letter = *ptr;
        int  offset = 0;
        if (isupper(letter))
        {
            offset = 32;
        }
        else if (islower(letter))
        {
            offset = -32;
        }
        *ptr = *ptr + offset;
        
        ptr = ptr + 1;
    }
}

bool greaterThan( char * cstring1, char * cstring2 )
{
    bool result = false;
    char * ptr1 = cstring1;
    char * ptr2 = cstring2;
    while (*ptr1 != '\0' && *ptr2 != '\0')
    {
        if (*ptr1 > *ptr2)
        {
            result = true;
            break;
        }
        else if (*ptr1 == *ptr2)
        {
            
        }
        else
        {
            result = false;
            break;
        }
        ptr1 = ptr1 + 1;
        ptr2 = ptr2 + 1;
    }
    // after running out of letters, are there still any letters left??
    if (*ptr1 != '\0')
    {
        result = false;
    }
    else if (*ptr2 != '\0')
    {
        result = true;
    }
    return( result );
}

void swapArrows( int * i, int * j )
{
    int * temp = i;
    i = j;
    j = temp;
}

void swapArrowsCorrected( int * & i, int * & j )
{
    int * temp = i;
    i = j;
    j = temp;
}
