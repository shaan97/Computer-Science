//
//  Dice.cpp
//  Dice
//
//  Created by Howard Stahl on 2/16/16.
//  Copyright © 2016 Howard Stahl. All rights reserved.
//

#include "Dice.h"
#include "RandomNumber.h"


namespace cs31
{
    
Dice::Dice( )
{
    mDie1 = 1;
    mDie2 = 1;
}
    
Dice::Dice( int die1, int die2 )
{
    mDie1 = die1;
    mDie2 = die2;
}
    
    
void Dice::roll()
{
    RandomNumber r( 1, 6 );
    mDie1 = r.random();
    mDie2 = r.random();
}
    
int  Dice::getDie1( ) const
{
    return( mDie1 );
}
    
int  Dice::getDie2( ) const
{
    return( mDie2 );
}
    
int  Dice::getTotal( ) const
{
    return( mDie1 + mDie2 );
}
    
    
    
}