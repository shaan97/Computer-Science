#include <iostream>
#include "RandomNumber.h"
#include "Dice.h"


int main( ) 
{
    using namespace std;
    using namespace cs31;
    
    Dice d;
    for (int i = 0; i <= 20; i++)
    {
        d.roll();
        cout << d.getTotal() << endl;
    }
    
    
//    d = Dice( -1, -1 );
//    cout << d.getTotal() << endl;
    
	return( 0 );
}