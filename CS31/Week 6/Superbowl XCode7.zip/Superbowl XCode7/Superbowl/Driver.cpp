#include "Header.h"


int main( )
{
	SuperbowlGame game = { 50, "Broncos", "Panthers", "" };
	updateWinner( game );
	printGame( game );
	SuperbowlGame game49 = createBowl49( );
	printGame( game49 );
}

void updateWinner( SuperbowlGame & g )
{
	string whoWon;
	cout << "Who won the Superbowl on Sunday? ";
	getline( cin, whoWon );
	g.mWinner = whoWon;
}

void printGame( const SuperbowlGame & g )
{
	cout << "----> Superbowl: " << g.mWhichOne << " ";
	cout << g.mAFCTeam << " vs. " << g.mNFCTeam << " ";
	cout << "----> Winner: " << g.mWinner << endl;
}

SuperbowlGame createBowl49( )
{
	SuperbowlGame game = { 49, "Patriots", "Seahawks", "Patriots" };
	return( game );
}