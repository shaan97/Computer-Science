#ifndef HEADER_H
#define HEADER_H
#include <iostream>
#include <string>
using namespace std;

struct SuperbowlGame {
	int mWhichOne;
	string mAFCTeam;
	string mNFCTeam;
	string mWinner;
};

void updateWinner( SuperbowlGame & g );
void printGame( const SuperbowlGame & g );
SuperbowlGame createBowl49( );

#endif