#include <iostream>
using namespace std;
#include "RandomNumber.h"


int main( ) 
{
	RandomNumber r( 1, 10 );
	for (int i = 0; i <= 20; i++)
	{
		cout << r.random() << " " << r.random( ) << " " << r.random() << endl;
	}
	return( 0 );
}