#include "Car.h"
#include <iostream>
using namespace std;

Car::Car()
{
	mMake = "";
	mModel = "";
}


Car::Car( string make, string model )
{
	mMake = make;
	mModel = model;
}


void Car::drive()
{
	cout << "drive" << endl;
}

void Car::honk( )
{
	cout << "honk" << endl;
}

void Car::stop( )
{
	cout << "stop" << endl;
}