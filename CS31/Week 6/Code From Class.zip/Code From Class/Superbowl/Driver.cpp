#include "Header.h"
#include "Car.h"
//#include "Car.cpp"

int main( )
{
	SuperbowlGame game = { 50, "Broncos", "Panthers", "" };
	game.mWhichOne = 50;
	game.mAFCTeam = "Broncos";
	game.mNFCTeam = "Panthers";
	game.mWinner = "Broncos";
	updateWinner( game );
	printGame( game );
	SuperbowlGame game49 = createBowl49( );
	printGame( game49 );

	Car c( "Honda", "Prelude" );
	c.drive();
	c.honk();
	c.stop();
	// c.mMake = "Honda";
	// c.mModel = "Prelude";
	int i, j, k;
	Car yourCar("Ford", "Fiesta");
	Car myCar("Chevy", "Volt" );
	Car d;

}

void updateWinner( SuperbowlGame & g )
{
	string whoWon;
	cout << "Who won the Superbowl on Sunday? ";
	getline( cin, whoWon );
	g.mWinner = whoWon;
}

void printGame( const SuperbowlGame & g )
{
	cout << "----> Superbowl: " << g.mWhichOne << " ";
	cout << g.mAFCTeam << " vs. " << g.mNFCTeam << " ";
	cout << "----> Winner: " << g.mWinner << endl;
}

SuperbowlGame createBowl49( )
{
	SuperbowlGame game = { 49, "Patriots", "Seahawks", "Patriots" };
	return( game );
}