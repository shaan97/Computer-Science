#ifndef CAR_H
#define CAR_H
#include <string>
using namespace std;

/// both data and operations together in a unit...
/// pattern we follow:
///    - operations marked public
///    - data member marked private
class Car
{

	void foo( );    /// private by default

public:            /// access modifiers
	               /// apply textual
	Car( string make, string model );
	Car();


	void drive();  /// methods   operations
	void honk( );
	void stop( );
private:           /// access modifier
	               /// apply textual
	string mMake;  /// member variables
	string mModel;
};


/// data:  mMake,   mModel     :  string
/// operations:  things a Car knows "how to do"


#endif