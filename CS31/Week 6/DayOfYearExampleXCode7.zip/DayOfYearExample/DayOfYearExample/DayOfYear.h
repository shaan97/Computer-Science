//
//  DayOfYear.h
//  DayOfYearExample
//
//  Created by Howard Stahl on 1/19/16.
//  Copyright © 2016 Howard Stahl. All rights reserved.
//

#ifndef DayOfYear_h
#define DayOfYear_h

class DayOfYear
{
public:
    void input( );
    void output( );
private:
    int month;
    int day;
};


#endif /* DayOfYear */
