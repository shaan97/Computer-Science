# include <iostream>

using namespace std;

void copy(char str1[], char str2[])
{
  int i;
  for(i = 0; str1[i] != '\0'; i++) {
    str2[i] = str1[i];
  }
  str2[i] = str1[i];
}

int main() {
  char str1[] = {'t', 'e', 's', 't', '\0'};
  char str2[] = {'0', '0', '0', '0', '0'};
  copy(str1, str2);
  for(int i = 0; str2[i] != '\0'; i++) {
    cout << str2[i] << endl;
  }
}
