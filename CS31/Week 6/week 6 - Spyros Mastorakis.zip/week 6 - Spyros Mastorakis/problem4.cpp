# include <iostream>
#include <string>

using namespace std;

struct myCompany {
  string employeeName;
  string position;
  int salary;
};

int main() {
  myCompany a;
  myCompany b = {"test", "test", 100};
  myCompany c;
  a.employeeName = "David Bruin";
  a.position = "Software Engineer";
  a.salary = 120000;
  cout << "Employee Name: " << a.employeeName << endl;
  cout << "Position: " << a.position << endl;
  cout << "Salary: " << a.salary << endl;
}
