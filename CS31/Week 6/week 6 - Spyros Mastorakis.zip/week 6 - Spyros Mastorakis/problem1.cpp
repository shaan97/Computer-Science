# include <iostream>

using namespace std;

int myStrLen(char a[])
{
  int counter = 0;
  for(int i = 0; a[i] != '\0'; i++) {
    counter++;
  }
  return counter;
}

int main() {
  char str[] = {'t', 'e', 's', 't', '\0'};
  cout << myStrLen(str) << endl;
}
