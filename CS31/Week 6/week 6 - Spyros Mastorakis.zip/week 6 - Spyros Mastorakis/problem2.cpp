# include <iostream>

using namespace std;

int myCompare(char str1[], char str2[])
{
  int i;
  for(i = 0; (str1[i] != '\0' || str2[i] != '\0') ; i++) {
    if (str1[i] > str2[i]) {
      return 1;
    }
    else if (str1[i] < str2[i]) {
      return -1;
    }
  }
  if (str1[i] != '\0') {
    return -1;
  }
  if (str2[i] != '\0') {
    return 1;
  }
  return 0;
}

int main() {
  char str1[] = {'t', 'e', 's', 't', '\0'};
  char str2[] = {'t', 'e', 's', 't', '\0'};
  cout << myCompare(str1, str2) << endl;
}
