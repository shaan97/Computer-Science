// This program demonstrates how variable scope occurs.
// Look at how the variable named "value" is processed.

#include <iostream>                // for std::cout
#include <cmath>				   // for math functions
using namespace std;               // supports cout

// precondition:  double argument assigned a value
// postcondition: floor, ceil, fabs and sqrt of argument is computed
//                and printed out to standard output
int compute_and_print( double d );

int main( )
{
  double value = 0.0;   // This variable is local to the main function
 
  cout << "Please enter a value for computations: " << endl;
  cin  >> value;
 
  compute_and_print( value );
  cout << "After the function call, value=" << value << endl;
  return 0;
}
 
int compute_and_print( double d ) {
  double value;         // This variable is local to this function
  value = floor( d );   
  cout << "\t floor_value = " << value << endl;
  value = ceil( d );
  cout << "\t ceil_value  = " << value  << endl;
  value = fabs( d );
  cout << "\t fabs_value  = " << value << endl;
  value = sqrt( d );
  cout << "\t sqrt_value  = " << value  << endl;
  
  return 0;
}
 
