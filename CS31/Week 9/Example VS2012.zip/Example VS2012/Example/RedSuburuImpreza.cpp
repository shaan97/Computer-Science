//
//  RedSuburuImpreza.cpp
//  Example
//
//  Created by Howard Stahl on 3/2/16.
//  Copyright © 2016 Howard Stahl. All rights reserved.
//

#include "RedSuburuImpreza.h"


namespace cs31
{
    
    RedSuburuImpreza::RedSuburuImpreza( double price )
    : SuburuImpreza( "red", price )
    {
        
    }
    
    
}