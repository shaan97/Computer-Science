//
//  SuburuImpreza.hpp
//  Example
//
//  Created by Howard Stahl on 3/2/16.
//  Copyright © 2016 Howard Stahl. All rights reserved.
//

#ifndef IMPREZA_H
#define IMPREZA_H

#include "Suburu.h"
#include <string>

namespace cs31
{

    class SuburuImpreza : public Suburu
    {
    public:
        SuburuImpreza( std::string color, double price );
    private:
        
    };
    
}

#endif
