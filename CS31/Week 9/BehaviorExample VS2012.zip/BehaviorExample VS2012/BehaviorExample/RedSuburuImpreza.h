//
//  RedSuburuImpreza.hpp
//  Example
//
//  Created by Howard Stahl on 3/2/16.
//  Copyright © 2016 Howard Stahl. All rights reserved.
//

#ifndef REDSUBURUIMPREZA
#define REDSUBURUIMPREZA

#include "SuburuImpreza.h"

namespace cs31
{

    class RedSuburuImpreza : public SuburuImpreza
    {
    public:
        RedSuburuImpreza( double price );
    private:
        
    };
    
}

#endif
