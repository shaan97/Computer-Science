//
//  SuburuImpreza.cpp
//  Example
//
//  Created by Howard Stahl on 3/2/16.
//  Copyright © 2016 Howard Stahl. All rights reserved.
//

#include "SuburuImpreza.h"


namespace cs31
{
    
    SuburuImpreza::SuburuImpreza( std::string color, double price )
    : Suburu( "Impreza", color, price )
    {
        
    }

    
    
}