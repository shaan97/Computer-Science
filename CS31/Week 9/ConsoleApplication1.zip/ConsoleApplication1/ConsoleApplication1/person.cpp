#include "Person.h"


Person::Person( std::string name, 
			   std::string address )
			   : mName( name ), 
			     mAddress( address )
				 /// initialization list
{
	//empty...
}
