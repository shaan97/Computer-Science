#ifndef STUDENT_H
#define STUDENT_H
#include "Person.h"
#include <string>

/// Student HAS-A Person!  "part of"
/// Student IS-A Person!   "kind of"
class Student : public Person
	// make a student different from a person...
{
public:
	Student( std::string name, std::string address,
		     std::string id );

	void print( );
private:
	std::string mStudentID;
};




#endif