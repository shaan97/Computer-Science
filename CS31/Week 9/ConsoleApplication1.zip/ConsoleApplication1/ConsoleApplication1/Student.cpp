#include <iostream>
#include "Student.h"

Student::Student( std::string name, std::string address,
		     std::string id )
			  : Person( name, address ), 
			  mStudentID( id )

			/// call our parent class constructor..
{
	// empty...
// 	Person( name, address );
//	mStudentID = id;
}

void Student::print()
{
	// this points at the object you are calling
	// the method on....
	// is pointing at the thing in front of the dot...
	//
	// Student s;
	// s.print();
	// int i = 21;
	// Student t;
	// t.print( );
	//
	using namespace std;
	cout << mName << mAddress << mStudentID << endl;
}