// This program calculates final grades in the C++ Programming
// course for a given student based on their grades on a midterm
// and final grade, equally weighted
//
#include <iostream>          // for std::cout and std::cin
using namespace std;         // supports cout and cin

int main( )
{
  // Declare needed variables
  int midterm_exam, final_exam;
  double grade;
	
  // Prompt the user for values
  cout << "\n\t\tGrader Calculator\n\n";
  cout << "Please enter Midterm exam score: ";
  cin  >> midterm_exam;
  cout << "Please enter Final exam score: ";
  cin  >> final_exam;

  // Compute the score
  grade = (midterm_exam + final_exam) / 2.0;

  // Display the score
  cout << "The student received an overall grade of ";
  cout << grade;
  cout << "\n\n";

  return 0;
}

