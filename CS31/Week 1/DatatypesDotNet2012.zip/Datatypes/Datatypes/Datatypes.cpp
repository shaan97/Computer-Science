// This program shows that declared variable datatypes consume memory.
// Each kind of datatype consumes a different amount of memory.  
// Each kind of datatype supports a different range of valid values.
// 
// The sizeof( ) function displays memory size in bytes 

#include <iostream>          // for std::cout and std::cin
#include <string>            // for std::string
using namespace std;         // supports cout and cin

int main( )
{
  cout << "The size of an int    is:\t";
  cout << sizeof(int);
  cout << " bytes\n";
  cout << "The size of a  short  is:\t";
  cout << sizeof(short);
  cout << " bytes\n";
  cout << "The size of a  long   is:\t";
  cout << sizeof(long);
  cout << " bytes\n";
  cout << "The size of a  char   is:\t";
  cout << sizeof(char);
  cout << " bytes\n";
  cout << "The size of a  float  is:\t";
  cout << sizeof(float);
  cout << " bytes\n";
  cout << "The size of a  double is:\t";
  cout << sizeof(double);
  cout << " bytes\n";
  cout << "The size of a  string is:\t";
  cout << sizeof(string);
  cout << " bytes\n";
  cout << "An unsigned int has size: ";
  cout << sizeof(unsigned int);
  cout << " bytes\n";
  cout << "An unsigned long has size: ";
  cout << sizeof(unsigned long);
  cout << " bytes\n";
  cout << "An unsigned short has size: ";
  cout << sizeof(unsigned short);
  cout << " bytes\n";



  // Exceeding the valid range of values for a datatype can yield 
  // interesting results
  unsigned short unsigned_short = 0;
  cout << "unsigned_short = ";
  cout << unsigned_short;
  unsigned_short--;
  cout << "\tunsigned_short = ";
  cout << unsigned_short;
  cout << "\n";

  unsigned int unsigned_int = 0;
  cout << "unsigned_int = ";
  cout << unsigned_int;
  unsigned_int--;
  cout << "\tunsigned_int = ";
  cout << unsigned_int;
  cout << "\n";

  unsigned long unsigned_long = 0;
  cout << "unsigned_long = ";
  cout << unsigned_long;
  unsigned_long--;
  cout << "\tunsigned_long = ";
  cout << unsigned_long;
  cout << "\n";


  return 0;
}
