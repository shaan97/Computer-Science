// This program displays a simple message
#include <iostream>		// for std::cout
using namespace std;	// supports cout

int main( ) 
{
  cout << "Hello World!\n";
  return 0;
}


