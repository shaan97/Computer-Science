// OperatorDriver.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <cstdlib>

#include "Number.h"

int main(int argc, char* argv[])
{
	using namespace std;
	using namespace cs52;

	Number four = Number( 4 );
	Number five = Number( 5 );

	cout << "----9----" << endl;
	Number nine = Number( 9 );
	nine.printRomanNumeral();

	cout << "----1----" << endl;
	Number one = Number( 1 );
	one.printRomanNumeral();

    cout << "----4----" << endl;
    four.printRomanNumeral();
    
    cout << "----5----" << endl;
    five.printRomanNumeral();
    
	return( 0 );
}

