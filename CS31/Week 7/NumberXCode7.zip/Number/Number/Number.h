#ifndef NUMBER_H
#define NUMBER_H

#include <iostream>
#include <cstdlib>

namespace cs52 {

class Number {
public:
	Number();
	Number( int initValue );

	void setValue( int v );
	int  getValue() const;
	void printRomanNumeral() const;

private:
	int value;
};

}

#endif