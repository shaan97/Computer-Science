// This program shows how selection statements can be combined together
// or "nested" inside one another.
// CAN ANYONE SPOT THE ERROR WITH THIS CODE, AS IT WON'T EVEN BUILD
// LET ALONE RUN!!!

#include <iostream>          // for std::cout and std::cin
using namespace std;         // supports cout and cin

int main( )
{
  double gpa = 0.0;
  const char A_AVERAGE = 'A', B_AVERAGE = 'B', C_AVERAGE = 'C';
  const char D_AVERAGE = 'D', F_AVERAGE = 'F';
 
  const double A_GPA = 3.5, B_GPA = 2.5, C_GPA = 1.5, D_GPA = 0.5;
  
  cout << "Please enter your grade point average:";
  cin  >> gpa;
 
  // What�s wrong with this compound statement?
  if (gpa >= D_GPA) 
     if (gpa >= C_GPA) 
        if (gpa >= B_GPA)		
           if (gpa >= A_GPA) 
		cout << "You're pulling an A average!\n";
		cout << "Keep up the good work!\n";
           else
		cout << "You're pulling a B average!\n";
		cout << "Keep it up!\n";
        else
	   cout << "You're pulling a C average!\n";
	   cout << "Strive for more!\n";
      else
    	cout << "You're pulling a D average!\n";
	cout << "Best if you study more!\n";
  else	
     cout << "You're pulling a F average!\n";
     cout << "You need to study more!\n";	
 
  return 0;
}

