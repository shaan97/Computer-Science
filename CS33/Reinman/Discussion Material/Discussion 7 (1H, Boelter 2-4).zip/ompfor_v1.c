#include "omp.h"
#include <stdio.h>

int foo (int i) { return i;}

int main()
{
	int sum = 0;
	omp_set_num_threads(10);
	#pragma omp parallel for
	for (int i = 0; i < 10; i++)
	{	
		sum += foo(i);
		printf("i = %d, foo(i) = %d; sum = %d \n",i,foo(i),sum); 
	}
	
	printf("sum = %d \n",sum); 
	return sum;
}
