
int ezThreeFourths(int);
int test_ezThreeFourths(int);
